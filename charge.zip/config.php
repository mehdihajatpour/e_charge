<?php
define('ENABLE',1);
define('USERNAME','admin');
define('PASSWORD','1111');
define('NAME','مجتبی جعفرزاده');
define('EMAIL','EMAIL@TEST.COM');
define('SEND_CHARGE_TO_MAIL_SUBJECT','کارت شارژ های خریداری شده از ایرانسل');
define('TITLE','Irancell eCharge Site');
define('KEYWORDS','charge,sell,extra,mobile,irancell,cheap');
define('DATABASE_NAME','skyf5_16915276_cshop1');
define('DATABASE_ADMIN','skyf5_16915276');
define('DATABASE_ADMIN_PASSWORD','527003');
define('DATABASE_HOST','sql304.skyf.ir');
define('TEMPLATE_NAME','default');
define('API','adxcv-zzadq-polkjsad-opp13opoz-1sdf455aadzmck1244567');
define('SEND_URL','http://payline.ir/payment-test/gateway-send');
define('GET_URL','http://payline.ir/payment-test/gateway-result-second');
$AMOUNTS=array(1=>10000,2=>20000,3=>50000,4=>100000,5=>200000,6=>500000,7=>1000000);
