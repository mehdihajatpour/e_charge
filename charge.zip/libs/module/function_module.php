<?php
/*تابع چک کردن کد کپچای فرم*/
function f_check_captcha($captcha,$go_page)
{
//بررسی وجود سشن کپچا
if(isset($_SESSION['captcha']))
$s_cap=$_SESSION['captcha'];
else
    F_Redirect($go_page);
//فیلد کپچا خالی نباشد
if(empty($captcha))
    F_Redirect($go_page);
//بررسی درستی کد کپچای وارد شده
if($captcha!=$s_cap)
    F_Redirect($go_page);
}

//تابع ریدایرکت کردن
function f_redirect($address)
{
    header('location:'.$address);
    exit();
}

function f_check_is_ajax()
{
    $isAjax = isset($_SERVER['HTTP_X_REQUESTED_WITH']) AND strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest';
    if(!$isAjax)
    {
        return true;
    }
}
/*تابع ساختن url  سایت*/
function f_full_url()
{
    return sprintf("%s://%s%s", isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off' ? 'https' : 'http', $_SERVER['SERVER_NAME'], $_SERVER['PHP_SELF']);
}
//تابع هش کردن رمز عبور
function f_hash_string($string)
{
    $salt="E%)^@g5%hh&N)&^6";
    return md5($string.$salt);
}
//ایمیل صحیح
function f_validate_email($email)
{
    if(filter_var($email, FILTER_VALIDATE_EMAIL))
        return 1;
    else
        return 0;
}
/*چک کردن صحت شماره موبایل*/
function f_validate_mobile($mobile)
{
    return preg_match('/^(((\+|00)98)|0)?9[0123]\d{8}$/', $mobile);
}